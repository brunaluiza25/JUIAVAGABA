<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/stylemenu.css">
    <title>Menu</title>
</head>

<body>
    <section id="cxprincipal">
        <header id="banner"></header>
        <nav id="cxamigo">         
                Cadastre seus amigos 
                <a href="telaamigos.php"  class="link-imagem">
                <figure><img src="img/conversa-fiada.png" alt=""></figure>
            </a>
        </nav>
        <nav id="cxcomercio">

                Cadastro seu comércio 
            <a href="telacadcomercial.php">
                <figure><img src="img/acordo.png" alt=""></figure>
            </a>
        </nav>
        <nav id="cxusuario">
                Cadastre-se
            <a href="telacaduser.php"> 
                <figure><img src="img/do-utilizador (1).png" alt=""></figure>
            </a>
        </nav>
        <nav id="cxconsultaamigo">
                Consulte seus Amigos 
            <a href="consultaamigos.php">    
                <figure><img src="img/mao-amiga.png" alt="" srcset=""></figure>
            </a>
        </nav>
        <nav id="cxconsultacomercio">
                Consulte seu comércio 
            <a href="consultacomercio.php"> 
                <figure><img src="img/comercio-e-compras.png" alt="" srcset=""></figure>
            </a>
        </nav>
        <nav id="cxconsultauser">
                Consulte-se 
            <a href="consultanomeuser.php">
                <figure><img src="img/adicionar-usuario.png" alt="" srcset=""></figure>
            </a>
        </nav>
        <footer id="rodape">
            <h4>&copy; 2024 Julia Dias Turma A. Todos os direitos reservados.</h4>
        </footer>
    </section>
    
</body>
</html>