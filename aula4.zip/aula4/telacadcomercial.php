<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styleuser.css">
    <title>Comercial</title>
    <script>
        function toggleForms() {
            var cadastroForm = document.getElementById("cadastroForm");
            var consultaForm = document.getElementById("consultaForm");

            cadastroForm.style.display = cadastroForm.style.display === "none" ? "block" : "none";
            consultaForm.style.display = consultaForm.style.display === "none" ? "block" : "none";
        }
    </script>
</head>

<body>
    <header>
        <h1>Cadastro Comercial</h1>
        <nav>
            <ul>
                <li><a href="index.php"> Menu</a></li>
                <li><a href="telacaduser.php">Cadastro </a></li>
                <li><a href="telacadcomercial.php">Amigos</a></li>
            </ul>
        </nav>
    </header>

    <form action="inserircomercial.php" method="POST" id="cadastroForm">
        Nome:
        <input type="text" name="cxnome" /><br />
        Comercio:
        <input type="text" name="cxcomercio" /><br />
        Telefone:
        <input type="text" name="cxtelefone" /><br />
        WhatsApp:
        <input type="text" name="cxwhats" /><br />
        <input type="submit" value="Gravar">
        <p>Já cadastrou sua comér? 
            <a href="#" onclick="toggleForms()" style="color: black;">Busque-a</a> 
        </p>
    </form>

    <form id="consultaForm" style="display:none;" action="CONSULTACOMERCIO.PHP" method="POST">
        Digite o nome do amigo: <br />
        <input type="text" name="amigo_name" />
        <input type="submit" value="Buscar" />
        <p>Ainda não cadastrou seu amigo?
            <a href="#" onclick="toggleForms()" style="color: black">Cadastre-se</a>
        </p>
    </form>

    <footer>
        <p>&copy; 2024 Julia Dias Turma A. Todos os direitos reservados.</p>
    </footer>

</body>

</html>
