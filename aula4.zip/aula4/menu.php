<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu</title>
    <link rel="stylesheet" href="css/stylemenu.css">
</head>
<body>
    <section id="cxprincipal">
        <header id="banner">ConectaMais</header>
        <nav id="cxamigo">Cadastre seus amigos <figure><img src="img/conversa-fiada.png" alt=""></figure></nav>
        <nav id="cxcomercio">Cadastro seu comercio  <figure><img src="img/acordo.png" alt=""></figure></nav>
        <nav id="cxusuario">Cadastro-se <figure><img src="img/do-utilizador (1).png" alt=""></figure> </nav>
        <nav id="cxconsultaamigo"></nav>
        <nav id="cxconsultacomercio"></nav>
        <nav id="cxconsultauser"></nav>
        <footer id="rodape"><h2>Juia</h2></footer>
    </section>
</body>
</html>